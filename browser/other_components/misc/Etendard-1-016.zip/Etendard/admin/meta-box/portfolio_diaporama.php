<?php

$cocorico = new Cocorico(ETENDARD_COCORICO_PREFIX, false);
$cocorico->diaporama('portfolio_diaporama');
$cocorico->render();