<section>
	<div class="wrapper">
		<?php
		the_post();
		get_template_part('content');
		?>
	</div>
</section>