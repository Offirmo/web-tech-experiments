<section>
	<div class="wrapper">
		<article class="article" itemscope itemtype="http://schema.org/Article">
			<div class="content" itemprop="articleBody">
				<p>
					<?php printf(__("Your custom home page isn't fully set up, you have to choose the elements to display on <a href='%s'>Etendard's settings page</a>.",'etendard'), admin_url('themes.php?page=etendard_options#general')); ?>
				</p>
			</div>
		</article>
	</div>
</section>