<section class="diaporama">
	<?php get_template_part('diaporama'); ?>
</section>