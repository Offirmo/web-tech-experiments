<sidebar class="sidebar col-1-3" role="complementary" itemscope="itemscope" itemtype="http://schema.org/WPSideBar">

	<?php do_action('etendard_sidebar_top'); ?>
	
		<?php dynamic_sidebar('blog'); ?>
	
	<?php do_action('etendard_sidebar_bottom'); ?>

</sidebar>