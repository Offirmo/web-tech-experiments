<?php

namespace Guzzle\Http\Exception;

/**
 * Exception when a server error is encountered (5xx codes)
 */
class ServerErrorResponseException extends BadResponseException {}
