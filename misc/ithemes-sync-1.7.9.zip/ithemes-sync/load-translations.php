<?php

/*
Loads up the translations for the plugin.
Written by Chris Jean for iThemes.com
Version 1.0.0

Version History
	1.0.0 - 2013-11-06 - Chris Jean
		Initial version
*/


load_plugin_textdomain( 'it-l10n-ithemes-sync', false, $GLOBALS['ithemes_sync_path'] . '/lang' );
